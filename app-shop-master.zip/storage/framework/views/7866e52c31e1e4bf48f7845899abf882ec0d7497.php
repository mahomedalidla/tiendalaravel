<?php $__env->startSection('title', 'Lista de Productos - Nombre tienda'); ?>
<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">

    </div>

    <div class="main main-raised">
        <div class="container">

        <div class="section text-center">
            <h2 class="title">Lista de Productos</h2>

            <div class="team">
                <a href=" <?php echo e(url('/admin/products/create')); ?> " class="btn btn-info btn-round">Nuevo Producto</a>
                <div class="row">

                    <table class="table">
                        <!-- Cabecera tabla -->
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th class="col-md-2 text-center">Nombre</th>
                                <th class="col-md-5 text-center">Descripción</th>
                                <th class="text-center">Categoría</th>
                                <th class="text-right">Precio</th>
                                <th class="text-center">Opciones</th>
                            </tr>
                        </thead>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <td class="text-center"><?php echo e($product->id); ?></td>
                                <td> <?php echo e($product->name); ?> </td>
                                <td><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td class="text-right">$ <?php echo e($product->price); ?> </td>
                                <td class="td-actions text-right">
                                    

                                    <form method="post" action="<?php echo e(url('/admin/products/'.$product->id)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        
                                        <a href="<?php echo e(url('/products/'.$product->id)); ?>" type="button" rel="tooltip" target="_blank" title="Ver Producto" class="btn btn-info btn-simple btn-xs">
                                        <i class="fa fa-info"></i>
                                        </a>
                                        <a href="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>" rel="tooltip" title="Editar Producto" class="btn btn-success btn-simple btn-xs">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <a href="<?php echo e(url('/admin/products/'.$product->id.'/images')); ?>" type="button" rel="tooltip" title="Imagenes del Producto" class="btn btn-warning btn-simple btn-xs">
                                        <i class="fa fa-image"></i>
                                        </a>

                                        <button type="submit" rel="tooltip" title="Eliminar" class="btn btn-danger btn-simple btn-xs">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </form>

                                </td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($products->links()); ?>

                </div>
            </div>

        </div>

        </div>

    </div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>