<?php $__env->startSection('title', ' Perfil - Nombre Tienda'); ?>
<?php $__env->startSection('body-class','product-page'); ?>
<?php $__env->startSection('content'); ?>
<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
            
</div>

    <div class="main main-raised">
        <div class="container">

            <div class="section ">
                <h2 class="title text-center">Perfil</h2>

                <!-- notificacion -->
                <?php if(session('notification')): ?>
                    <div class="alert alert-danger ">
                    <?php echo e(session('notification')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('notificationP')): ?>
                    <div class="alert alert-success ">
                    <?php echo e(session('notificationP')); ?>

                    </div>
                <?php endif; ?>

                    <ul class="nav nav-pills nav-pills-primary" role="tablist">
                        <li class="active">
                            <a href="#dashboard" role="tab" data-toggle="tab">
                                <i class="material-icons">dashboard</i>
                                Carrito de compras
                            </a>
                        </li>
                        <li>
                            <a href="#tasks" role="tab" data-toggle="tab">
                                <i class="material-icons">list</i>
                                Pedidos Realizados
                            </a>
                        </li>
                    </ul>

                    <hr>
                    <p class="text-center"> Tu carrito de compras tiene <?php echo e(auth()->user()->cart->details->count()); ?> productos.</p>
                    <hr>
                    <table class="table">
                        <!-- Cabecera tabla -->
                        <thead>
                            <tr>
                                <th class="text-center">Imagen</th>
                                <th class="text-center">Nombre</th>
                                <th>Precio</th>
                                <th>Cantidad</th>
                                <th>Subtotal</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>

                        <?php $__currentLoopData = auth()->user()->cart->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <td class="text-center">
                                    <img src="<?php echo e($detail->product->featured_image_url); ?>" height="50">
                                </td>

                                <td>
                                 <a href="<?php echo e(url('/products/'.$detail->product->id)); ?>" class="text-center" target="_blank" > <?php echo e($detail->product->name); ?> </a>
                                 </td>

                                <td>$ <?php echo e($detail->product->price); ?> </td>
                                <td><?php echo e($detail->quantity); ?></td>
                                <td>$ <?php echo e($detail->quantity * $detail->product->price); ?></td>

                                <td class="td-actions text-right">

                                    <form method="post" action="<?php echo e(url('/cart')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <input type="hidden" name="cart_detail_id" value="<?php echo e($detail->id); ?>">

                                        <a href="<?php echo e(url('/products/'.$detail->product->id)); ?>" target="_blank" type="button" rel="tooltip" title="Ver Producto" class="btn btn-info btn-simple btn-xs">
                                        <i class="fa fa-info"></i>
                                        </a>

                                        <button type="submit" rel="tooltip" title="Eliminar" class="btn btn-danger btn-simple btn-xs">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </form>

                                </td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <form method="post" action="<?php echo e(url('/order')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <p><strong>Importe a pagar: </strong> <?php echo e(auth()->user()->cart->total); ?></p>
                        <div class="text-center">
                            <button class="btn btn-success btn-round">
                                <i class="material-icons">add_shopping_cart</i>  Realizar pedido
                            </button>
                        </div>
                    </form>

                </div>
        </div>
    </div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>