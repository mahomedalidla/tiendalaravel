<footer class="footer">
        <div class="container">
            <nav class="pull-left">
                <ul>
                    <li>
                        <a href="#">
                            CreeHaz
                        </a>
                    </li>
                    <li>
                        <a href="#">
                           Sobre Nosotros
                        </a>
                    </li>
                    <li>
                        <a href="#">
                           Blog
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Licencia
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; 2019 Creado por <a href="https://www.facebook.com/CreeHaz" target="_blank">CreeHaz</a> <i class="fa fa-heart heart"></i>
            </div>
        </div>
</footer>